IEEE Photonics

The following files are available in the IEEEphot.zip archive:

IEEEphot_HOWTO.pdf  - This is the PDF file of Author Guide for Template
IEEEphot_sample.pdf - This is the PDF file of sample LaTeX document of Template
IEEEphot.cls        - This is the LaTeX2e class file of IEEE Photonics

IEEEphot_sample.tex -  LaTeX document of sample
IEEEphot_sample.bib -  LaTeX document of bibliograpies
mouse.eps           - Graphics file used in sample

Happy TeXing!!!

Aptara